export type Product = {
  id: string;
  name: string;
  tagline: string;
  category: 'Audio' | 'Wearables' | 'Computing' | 'Vision' | 'Home' | 'Gaming';
  price: number;
  rating: number;
  reviews: number;
  image: string;
  badge?: string;
  specs: { label: string; value: string }[];
  description: string;
};

export function getProducts(): Product[] {
  const stored = localStorage.getItem('nexus-products');
  return stored ? JSON.parse(stored) : [];
}

export function saveProducts(products: Product[]): void {
  localStorage.setItem('nexus-products', JSON.stringify(products));
}

export function addProduct(product: Product): void {
  const products = getProducts();
  products.push(product);
  saveProducts(products);
}

export function deleteProduct(id: string): void {
  const products = getProducts().filter(p => p.id !== id);
  saveProducts(products);
}

export function updateProduct(updated: Product): void {
  const products = getProducts().map(p => p.id === updated.id ? updated : p);
  saveProducts(products);
}
