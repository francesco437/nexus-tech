import { useState, useEffect } from 'react'
import { Product, getProducts, addProduct, deleteProduct, updateProduct } from '../lib/products'

const ADMIN_PASSWORD = 'admin123'

const emptyProduct: Omit<Product, 'id'> = {
  name: '',
  tagline: '',
  category: 'Audio',
  price: 0,
  rating: 5,
  reviews: 0,
  image: '',
  badge: '',
  specs: [],
  description: '',
}

export default function AdminPage({ onBack }: { onBack: () => void }) {
  const [authed, setAuthed] = useState(false)
  const [password, setPassword] = useState('')
  const [products, setProducts] = useState<Product[]>([])
  const [form, setForm] = useState(emptyProduct)
  const [editId, setEditId] = useState<string | null>(null)
  const [specInput, setSpecInput] = useState({ label: '', value: '' })

  useEffect(() => {
    if (authed) setProducts(getProducts())
  }, [authed])

  if (!authed) {
    return (
      <div className="min-h-screen bg-gray-950 flex items-center justify-center">
        <div className="bg-gray-900 p-8 rounded-2xl w-80">
          <h2 className="text-white text-2xl font-bold mb-6 text-center">Admin Login</h2>
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            className="w-full bg-gray-800 text-white px-4 py-3 rounded-lg mb-4 outline-none"
            onKeyDown={e => e.key === 'Enter' && password === ADMIN_PASSWORD && setAuthed(true)}
          />
          <button
            onClick={() => password === ADMIN_PASSWORD ? setAuthed(true) : alert('Password errata!')}
            className="w-full bg-purple-600 hover:bg-purple-500 text-white py-3 rounded-lg font-semibold transition"
          >
            Accedi
          </button>
        </div>
      </div>
    )
  }

  const handleSubmit = () => {
    if (!form.name || !form.price) return alert('Nome e prezzo obbligatori!')
    if (editId) {
      updateProduct({ ...form, id: editId })
    } else {
      addProduct({ ...form, id: crypto.randomUUID() })
    }
    setProducts(getProducts())
    setForm(emptyProduct)
    setEditId(null)
  }

  const handleEdit = (p: Product) => {
    setEditId(p.id)
    setForm({ ...p })
  }

  const handleDelete = (id: string) => {
    if (confirm('Eliminare questo prodotto?')) {
      deleteProduct(id)
      setProducts(getProducts())
    }
  }

  const addSpec = () => {
    if (specInput.label && specInput.value) {
      setForm({ ...form, specs: [...form.specs, specInput] })
      setSpecInput({ label: '', value: '' })
    }
  }

  return (
    <div className="min-h-screen bg-gray-950 text-white p-6">
      <div className="flex items-center gap-4 mb-8">
        <button onClick={onBack} className="text-gray-400 hover:text-white transition">← Torna al sito</button>
        <h1 className="text-3xl font-bold">Admin <span className="text-purple-400">Panel</span></h1>
      </div>

      <div className="bg-gray-900 rounded-2xl p-6 mb-10">
        <h2 className="text-xl font-semibold mb-4">{editId ? 'Modifica Prodotto' : 'Aggiungi Prodotto'}</h2>
        <div className="grid grid-cols-2 gap-4">
          <input placeholder="Nome" value={form.name} onChange={e => setForm({...form, name: e.target.value})} className="bg-gray-800 px-4 py-2 rounded-lg outline-none" />
          <input placeholder="Tagline" value={form.tagline} onChange={e => setForm({...form, tagline: e.target.value})} className="bg-gray-800 px-4 py-2 rounded-lg outline-none" />
          <select value={form.category} onChange={e => setForm({...form, category: e.target.value as Product['category']})} className="bg-gray-800 px-4 py-2 rounded-lg outline-none">
            {['Audio','Wearables','Computing','Vision','Home','Gaming'].map(c => <option key={c}>{c}</option>)}
          </select>
          <input placeholder="Prezzo (€)" type="number" value={form.price} onChange={e => setForm({...form, price: +e.target.value})} className="bg-gray-800 px-4 py-2 rounded-lg outline-none" />
          <input placeholder="Badge (es. New, Featured)" value={form.badge} onChange={e => setForm({...form, badge: e.target.value})} className="bg-gray-800 px-4 py-2 rounded-lg outline-none" />
          <input placeholder="URL Immagine" value={form.image} onChange={e => setForm({...form, image: e.target.value})} className="bg-gray-800 px-4 py-2 rounded-lg outline-none" />
          <textarea placeholder="Descrizione" value={form.description} onChange={e => setForm({...form, description: e.target.value})} className="bg-gray-800 px-4 py-2 rounded-lg outline-none col-span-2" rows={3} />
        </div>

        <div className="mt-4">
          <p className="text-sm text-gray-400 mb-2">Specifiche tecniche</p>
          <div className="flex gap-2 mb-2">
            <input placeholder="Label (es. Battery)" value={specInput.label} onChange={e => setSpecInput({...specInput, label: e.target.value})} className="bg-gray-800 px-4 py-2 rounded-lg outline-none flex-1" />
            <input placeholder="Valore (es. 60h)" value={specInput.value} onChange={e => setSpecInput({...specInput, value: e.target.value})} className="bg-gray-800 px-4 py-2 rounded-lg outline-none flex-1" />
            <button onClick={addSpec} className="bg-purple-600 hover:bg-purple-500 px-4 py-2 rounded-lg transition">+</button>
          </div>
          <div className="flex flex-wrap gap-2">
            {form.specs.map((s, i) => (
              <span key={i} className="bg-gray-800 text-sm px-3 py-1 rounded-full">{s.label}: {s.value} <button onClick={() => setForm({...form, specs: form.specs.filter((_,j) => j !== i)})} className="ml-1 text-red-400">×</button></span>
            ))}
          </div>
        </div>

        <button onClick={handleSubmit} className="mt-6 bg-purple-600 hover:bg-purple-500 px-8 py-3 rounded-lg font-semibold transition">
          {editId ? 'Salva Modifiche' : 'Aggiungi Prodotto'}
        </button>
        {editId && <button onClick={() => { setEditId(null); setForm(emptyProduct) }} className="mt-6 ml-4 bg-gray-700 hover:bg-gray-600 px-8 py-3 rounded-lg font-semibold transition">Annulla</button>}
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-4">Prodotti ({products.length})</h2>
        {products.length === 0 ? (
          <p className="text-gray-500">Nessun prodotto ancora.</p>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {products.map(p => (
              <div key={p.id} className="bg-gray-900 rounded-xl p-4 flex justify-between items-center">
                <div>
                  <p className="font-semibold">{p.name} <span className="text-purple-400">€{p.price}</span></p>
                  <p className="text-sm text-gray-400">{p.category} · {p.tagline}</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => handleEdit(p)} className="bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded-lg text-sm transition">Modifica</button>
                  <button onClick={() => handleDelete(p.id)} className="bg-red-900 hover:bg-red-800 px-4 py-2 rounded-lg text-sm transition">Elimina</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
