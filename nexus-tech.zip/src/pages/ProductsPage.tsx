import { useState, useEffect } from 'react'
import { Product, getProducts } from '../lib/products'

export default function ProductsPage({ onAddToCart }: { onAddToCart: (p: Product) => void }) {
  const [products, setProducts] = useState<Product[]>([])
  const [category, setCategory] = useState<string>('All')

  useEffect(() => {
    setProducts(getProducts())
  }, [])

  const categories = ['All', ...Array.from(new Set(products.map(p => p.category)))]
  const filtered = category === 'All' ? products : products.filter(p => p.category === category)

  if (products.length === 0) {
    return (
      <div className="text-center py-20">
        <h2 className="text-4xl font-bold text-white">Products</h2>
        <p className="text-gray-400 mt-4">Nessun prodotto ancora. Aggiungili dal pannello Admin!</p>
      </div>
    )
  }

  return (
    <div className="py-10">
      <h2 className="text-4xl font-bold text-white mb-6">Products</h2>
      <div className="flex gap-3 mb-8 flex-wrap">
        {categories.map(c => (
          <button key={c} onClick={() => setCategory(c)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition ${category === c ? 'bg-purple-600 text-white' : 'bg-gray-800 text-gray-400 hover:text-white'}`}>
            {c}
          </button>
        ))}
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map(p => (
          <div key={p.id} className="bg-gray-900 rounded-2xl overflow-hidden hover:ring-1 hover:ring-purple-500 transition">
            {p.image && <img src={p.image} alt={p.name} className="w-full h-48 object-cover" />}
            {!p.image && <div className="w-full h-48 bg-gray-800 flex items-center justify-center text-gray-600 text-4xl">📦</div>}
            <div className="p-5">
              {p.badge && <span className="text-xs bg-purple-600 text-white px-2 py-1 rounded-full mb-2 inline-block">{p.badge}</span>}
              <h3 className="text-white font-bold text-lg">{p.name}</h3>
              <p className="text-gray-400 text-sm mb-3">{p.tagline}</p>
              <p className="text-purple-400 font-bold text-xl mb-4">€{p.price}</p>
              <button onClick={() => onAddToCart(p)}
                className="w-full bg-purple-600 hover:bg-purple-500 text-white py-2 rounded-lg font-semibold transition">
                Aggiungi al carrello
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
