import { useState } from 'react'
import AdminPage from './pages/AdminPage'
import ProductsPage from './pages/ProductsPage'
import { Product } from './lib/products'

type Page = 'home' | 'products' | 'cart' | 'admin'

export default function App() {
  const [page, setPage] = useState<Page>('home')
  const [cart, setCart] = useState<Product[]>([])

  const addToCart = (p: Product) => {
    setCart(prev => [...prev, p])
  }

  const total = cart.reduce((sum, p) => sum + p.price, 0)

  if (page === 'admin') return <AdminPage onBack={() => setPage('home')} />

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <nav className="fixed top-0 w-full z-50 bg-gray-950/80 backdrop-blur border-b border-gray-800 px-6 py-4 flex justify-between items-center">
        <span className="text-xl font-bold tracking-tight cursor-pointer" onClick={() => setPage('home')}>
          NEXUS<span className="text-purple-400">TECH</span>
        </span>
        <div className="flex gap-6 text-sm text-gray-400">
          <button onClick={() => setPage('home')} className="hover:text-white transition">Home</button>
          <button onClick={() => setPage('products')} className="hover:text-white transition">Products</button>
          <button onClick={() => setPage('cart')} className="hover:text-white transition relative">
            Cart {cart.length > 0 && <span className="ml-1 bg-purple-600 text-white text-xs px-1.5 py-0.5 rounded-full">{cart.length}</span>}
          </button>
          <button onClick={() => setPage('admin')} className="hover:text-purple-400 transition">Admin</button>
        </div>
      </nav>

      <main className="pt-20 px-6 max-w-6xl mx-auto">
        {page === 'home' && (
          <div className="flex flex-col items-center justify-center min-h-[80vh] text-center">
            <h1 className="text-6xl font-bold mb-4">The Future of <span className="text-purple-400">Tech</span></h1>
            <p className="text-gray-400 text-xl mb-8">Premium devices for those who demand more.</p>
            <button onClick={() => setPage('products')} className="bg-purple-600 hover:bg-purple-500 px-8 py-3 rounded-full font-semibold transition">
              Shop Now
            </button>
          </div>
        )}
        {page === 'products' && <ProductsPage onAddToCart={addToCart} />}
        {page === 'cart' && (
          <div className="py-10">
            <h2 className="text-4xl font-bold mb-6">Cart</h2>
            {cart.length === 0 ? (
              <p className="text-gray-400">Il carrello è vuoto.</p>
            ) : (
              <>
                <div className="space-y-4 mb-6">
                  {cart.map((p, i) => (
                    <div key={i} className="bg-gray-900 rounded-xl p-4 flex justify-between items-center">
                      <div>
                        <p className="font-semibold">{p.name}</p>
                        <p className="text-sm text-gray-400">{p.category}</p>
                      </div>
                      <p className="text-purple-400 font-bold">€{p.price}</p>
                    </div>
                  ))}
                </div>
                <div className="bg-gray-900 rounded-xl p-6">
                  <div className="flex justify-between items-center mb-4">
                    <span className="text-xl font-bold">Totale</span>
                    <span className="text-purple-400 text-2xl font-bold">€{total}</span>
                  </div>
                  <button className="w-full bg-purple-600 hover:bg-purple-500 py-3 rounded-lg font-semibold transition">
                    Procedi al pagamento
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </main>
    </div>
  )
}
